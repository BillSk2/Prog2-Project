package prog2.lexiko;

import static org.junit.Assert.*;

import org.junit.Test;

public class ScanTest {

	@Test
	public void test() {
		
	}

}
