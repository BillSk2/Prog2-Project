package code;

import static org.junit.Assert.*;

import org.junit.Test;

public class UserInputTest {

	@Test
	public void test() {
		
	}

}
